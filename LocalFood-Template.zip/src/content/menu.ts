import type { MenuCategory } from "../types/business";

import taco1 from "../assets/menu/Taco1.webp";

export const menuCategories: MenuCategory[] = [
    {
        id: "tacos",
        name: "Tacos",
        description: "Nuestros sabores tradicionales.",
        items: [
            {
                id: "prensado",
                name: "Prensado",
                available: true,
                image: taco1,
            },
            {
                id: "chorizo",
                name: "Chorizo",
                available: true,
                image: taco1,
            },
            {
                id: "papa",
                name: "Papa",
                available: true,
                priceLabel: "$2.50",
                image: taco1,
            },
            {
                id: "frijol",
                name: "Frijol",
                description: "Taco de frijol con queso.",
                price: 2.5,
                priceLabel: "$2.50",
                available: true,
                image: taco1,
            },
            {
                id: "queso",
                name: "Queso",
                available: true,
            },
            {
                id: "costilla",
                name: "Costilla",
                available: true,
            }
        ]
    }
]