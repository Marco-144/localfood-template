import { ArrowUpRight } from "lucide-react";

import { DishFallbackIcon, Sparkle } from "../decor/FoodDoodles";

type CardVariant = "image" | "split" | "accent" | "minimal";

interface MenuItemCardProps {
    name: string;
    index: number;
    description?: string;
    price?: number;
    priceLabel?: string;
    image?: string;
    variant: CardVariant;
}

/**
 * Fondo de respaldo usado en TODAS las variantes cuando el
 * producto no tiene foto todavía.
 *
 * Importante para la plantilla: muchos negocios que la usen no
 * tendrán fotografía propia del producto al inicio. En vez de dejar
 * un espacio vacío (o forzar una foto de stock que no calce con la
 * marca), mostramos un ícono de plato genérico sobre un degradado
 * con los colores de marca. Así ninguna tarjeta se ve "rota" o
 * incompleta, sin importar cuántas fotos existan.
 */

function FallbackArt({ tone = "dark" }: { tone?: "dark" | "ligth" }) {
    return (
        <div
            className={`
                absolute inset-0 flex items-center justify-center
                bg-linear-to-br
                ${tone === "dark"
                    ? "from-primary/15 via-transparent to-secondary/15"
                    : "from-primary/25 via-primary/5 to-secondary/20"}
            `}>
            <DishFallbackIcon
                className={`h-16 w-16 sm:h-20 sm:w-20 ${tone === "dark" ?
                    "text-white/15" : "text-black/15"}`} />
        </div>
    );
}

function MenuItemCard({ name, index, description, price, priceLabel, image, variant = "image" }: MenuItemCardProps) {
    const priceText = priceLabel ??
        (price !== undefined
            ? `$${price.toLocaleString("es-MX")}`
            : undefined
        );

    const hasImage = Boolean(image);

    /**
     * ------------------
     * VARIANT: SPLIT
     * ------------------
     * La imagen ocupa una parte de la tarjeta y el contenido
     * vive en otra. Funciona especialmente bien con imágenes
     * verticales.
     */

    if (variant === "split") {
        return (
            <article className="
                group
                relative
                grid
                min-h-72
                overflow-hidden
                rounded-card
                bg-surface
                text-white
                transition-all
                duration-500
                hover:-translate-y-1
                hover:shadow-soft
                sm:min-h-80">

                {/* Decorative accent */}
                <div className="
                    pointer-events-none
                    absolute
                    -right-16
                    -top-16
                    size-40
                    rounded-full
                    bg-primary/10
                    blur-3xl
                    transition-transform
                    duration-700
                    group-hover:scale-125" />


                <div className="grid min-h-full grid-cols-[1fr_1fr] sm:grid-cols-[0.55fr_1.45fr]">
                    {/* Content */}
                    <div className="relative z-10 flex flex-col justify-between p-5 sm:p-6">
                        <div className="flex items-start justify-between">
                            <span className="
                                flex
                                size-9
                                items-center
                                justify-center
                                rounded-full
                                border
                                border-white/10
                                text-[10px]
                                font-bold
                                tracking-wider
                                text-white/40">
                                {String(index + 1).padStart(2, "0")}
                            </span>

                            {priceText && (
                                <span className="
                                    rounded-full
                                    bg-primary
                                    px-3
                                    py-1.5
                                    text-xs
                                    font-bold
                                    text-black">
                                    {priceText}
                                </span>
                            )}
                        </div>

                        <div>
                            <h3 className="
                                font-display
                                text-2xl
                                uppercase
                                leading-[0.9]
                                tracking-tight
                                sm:text-3xl">
                                {name}
                            </h3>

                            {description && (
                                <p className="mt-3 max-w-44 text-sm leading-5 text-white/45">
                                    {description}
                                </p>
                            )}

                            <span className="
                                mt-5
                                flex
                                size-9
                                items-center
                                justify-center
                                rounded-full
                                border
                                border-white/10
                                text-white/30
                                transition-all
                                duration-300
                                group-hover:border-primary
                                group-hover:bg-primary
                                group-hover:text-black">
                                <ArrowUpRight size={16} />
                            </span>
                        </div>
                    </div>

                    {/* Image */}
                    <div className="relative min-h-full overflow-hidden">
                        {hasImage ? (
                            <>
                                <img
                                    src={image}
                                    alt={name}
                                    className="
                                        absolute
                                        inset-0
                                        h-full
                                        w-full
                                        object-cover
                                        transition-transform
                                        duration-700
                                        group-hover:scale-105" />

                                <div className="
                                    absolute
                                    inset-y-0
                                    left-0
                                    w-1/3
                                    bg-linear-to-r
                                    from-surface
                                    to-transparent" />
                            </>
                        ) : (
                            <FallbackArt tone="dark" />
                        )}
                    </div>
                </div>
            </article>
        );
    }

    /**
     * ------------------
     * VARIANT: ACCENT
     * ------------------
     * Tarjeta más gráfica. Ideal para romper la repetición
     * visual del grid.
     */
    if (variant === "accent") {
        return (
            <article className="
                group
                relative
                min-h-72
                overflow-hidden
                rounded-card
                bg-primary
                text-black
                transition-all
                duration-500
                hover:-translate-y-1
                hover:shadow-soft
                sm:min-h-80">

                {/* Graphic circle */}
                <div className="
                    pointer-events-none
                    absolute
                    -right-24
                    -bottom-24
                    size-64
                    rounded-full
                    border-[24px]
                    border-black/10
                    transition-transform
                    duration-700
                    group-hover:scale-110" />

                {/* Image */}
                {hasImage && (
                    <div className="
                        pointer-events-none
                        absolute
                        -right-6
                        -top-6
                        size-32 
                        overflow-hidden
                        rounded-full
                        border-4
                        border-black/10
                        opacity-90
                        transition-transform
                        duration-700
                        group-hover:scale-105
                        sm:size-40">
                        <img
                            src={image}
                            alt=""
                            className="h-full w-full object-cover" />
                    </div>
                )}

                <div className="relative flex min-h-72 flex-col justify-between p-5 sm:min-h-80 sm:p-6">
                    <div className="flex items-start justify-between">
                        <span className="
                            flex
                            size-9
                            items-center
                            justify-center
                            rounded-full
                            border
                            border-black/20
                            text-[10px]
                            font-bold
                            tracking-wider">
                            {String(index + 1).padStart(2, "0")}
                        </span>

                        {priceText && (
                            <span className="
                                rounded-full
                                bg-black
                                px-3
                                py-1.5
                                text-xs
                                font-bold
                                text-white">
                                {priceText}
                            </span>
                        )}
                    </div>

                    <div className="flex items-end justify-between gap-4">
                        <div>
                            <h3 className="
                                font-display
                                text-3xl
                                uppercase
                                leading-[0.88]
                                tracking-tight
                                sm:text-4xl">
                                {name}
                            </h3>

                            {description && (
                                <p className="mt-3 max-w-xs text-sm leading-5 text-black/60">
                                    {description}
                                </p>
                            )}
                        </div>

                        <span className="
                            flex
                            size-10
                            shrink-0
                            items-center
                            justify-center
                            rounded-full
                            bg-black
                            text-white
                            transition-transform
                            duration-300
                            group-hover:rotate-45">
                            <ArrowUpRight size={17} />
                        </span>
                    </div>
                </div>
            </article>
        );
    }

    /**
     * ------------------
     * VARIANT: MINIMAL
     * ------------------
     * Tarjeta principalmente tipográfica.
     * Sirve para que no todo dependa de fotografías.
     */

    if (variant === "minimal") {
        return (
            <article className="
                group
                relative
                flex
                min-h-64
                overflow-hidden
                rounded-card
                border
                border-black/10
                bg-white
                p-5
                text-black
                transition-all
                duration-500
                hover:-translate-y-1
                hover:border-primary
                hover:shadow-soft
                sm:min-h-72
                sm:p-6">

                {/* Watermark decorativo, siempre presente */}
                <Sparkle className="
                    pointer-events-none
                    absolute
                    -right-6
                    -top-6
                    size-28
                    text-primary/15
                    transition-transform
                    duration-700
                    group-hover:rotate-12
                    sm:size-32" />

                <div className="relative flex w-full flex-col justify-between">
                    <div className="flex items-start justify-between">
                        <span className="
                            text-[10px]
                            font-bold
                            tracking-[0.2em]
                            text-black/30" >
                            {String(index + 1).padStart(2, "0")}
                        </span>

                        {priceText && (
                            <span className="text-xs font-bold text-primary">
                                {priceText}
                            </span>
                        )}
                    </div>

                    <div>
                        <div className="
                            mb-5
                            h-1
                            w-10
                            bg-secondary
                            transition-all
                            duration-300
                            group-hover:w-16" />

                        <h3 className="
                            font-display
                            text-3xl
                            uppercase
                            leading-[0.9]
                            tracking-tight">
                            {name}
                        </h3>

                        {description && (
                            <p className="mt-3 max-w-xs text-sm leading-6 text-black/45">
                                {description}
                            </p>
                        )}
                    </div>
                </div>

                <span className="
                    absolute
                    bottom-5
                    right-5
                    flex
                    size-9
                    items-center
                    justify-center
                    rounded-full
                    border
                    border-black/10
                    text-black/30
                    transition-all
                    duration-300
                    group-hover:border-primary
                    group-hover:bg-primary
                    group-hover:text-black">
                    <ArrowUpRight size={16} />
                </span>
            </article>
        );
    }

    /**
     * ------------------
     * VARIANT: IMAGE
     * ------------------
     * Tarjeta principal para fotografías / ilustraciones.
     */

    return (
        <article className="
            group 
            relative 
            min-h-72
            overflow-hidden 
            rounded-card 
            bg-black
            text-white 
            transition-all 
            duration-500 
            hover:-translate-y-1 
            hover:shadow-soft
            sm:min-h-80">

            {/* Image */}
            {image ? (
                <div className="absolute inset-0">
                    <img
                        src={image}
                        alt={name}
                        className="
                            h-full
                            w-full
                            object-cover
                            transition-transform
                            duration-700
                            group-hover:scale-105" />

                    <div className="absolute inset-0 bg-linear-to-t from-black via-black/35 to-transparent" />
                </div>
            ) : (
                <FallbackArt tone="dark" />
            )}

            {/* Content */}
            <div className="relative flex min-h-72 flex-col justify-between p-5 sm:min-h-80 sm:p-6">

                {/* Top */}
                <div className="flex items-start justify-between">
                    <span className="
                        flex 
                        size-9 
                        items-center 
                        justify-center 
                        rounded-full 
                        border 
                        border-white/15
                        bg-black/10 
                        text-[10px] 
                        font-bold
                        tracking-wider 
                        text-white/60
                        backdrop-blur-sm">
                        {String(index + 1).padStart(2, "0")}
                    </span>

                    {priceText && (
                        <span className="
                            rounded-full
                            bg-white
                            px-3
                            py-1.5
                            text-xs
                            font-bold
                            text-black">
                            {priceText}
                        </span>
                    )}
                </div>

                {/* Bottom */}
                <div>
                    <div className="flex items-end justify-between gap-4">
                        <div>
                            <h3 className="font-display text-3xl uppercase leading-[0.88] tracking-tight sm:text-4xl">
                                {name}
                            </h3>

                            {description && (
                                <p className="mt-3 max-w-xs text-sm leading-6 text-white/55">
                                    {description}
                                </p>
                            )}
                        </div>

                        <span className="
                            flex
                            size-10
                            shrink-0
                            items-center
                            justify-center
                            rounded-full
                            border
                            border-white/15
                            text-white/40
                            transition-all
                            duration-300
                            group-hover:border-primary
                            group-hover:bg-primary
                            group-hover:text-black">
                            <ArrowUpRight size={17} />
                        </span>
                    </div>
                </div>
            </div>
        </article>
    );
}

export default MenuItemCard;